// Root outputs.tf
