// Root variables.tf
