terraform {
  backend "s3" {
    bucket         = "my-tf-prod-state"
    key            = "infra/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "tf-locks"
    encrypt        = true
  }
}